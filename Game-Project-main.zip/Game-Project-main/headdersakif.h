#ifndef new_Header
#define new_Header

int lv01Enemy02FWM[4];
int lv01Enemy02Atk[5];
int lv01Enemy02Ded[3];


int lv01Enemy03FWM[3];
int lv01Enemy03Atk[4];
int lv01Enemy03Ded[2];

lv01Enemy02FWM[0] = iLoadImage("images\\LevelOneEnemy\\Enemy02\\01.png");
lv01Enemy02FWM[1] = iLoadImage("images\\LevelOneEnemy\\Enemy02\\02.png");
lv01Enemy02FWM[2] = iLoadImage("images\\LevelOneEnemy\\Enemy02\\03.png");
lv01Enemy02FWM[3] = iLoadImage("images\\LevelOneEnemy\\Enemy02\\04.png");


lv01Enemy02Atk[0] = iLoadImage("images\\LevelOneEnemy\\Enemy02\\Atk01.png");
lv01Enemy02Atk[1] = iLoadImage("images\\LevelOneEnemy\\Enemy02\\Atk02.png");
lv01Enemy02Atk[2] = iLoadImage("images\\LevelOneEnemy\\Enemy02\\Atk03.png");
lv01Enemy02Atk[3] = iLoadImage("images\\LevelOneEnemy\\Enemy02\\Atk04.png");
lv01Enemy02Atk[4] = iLoadImage("images\\LevelOneEnemy\\Enemy02\\Atk05.png");


lv01Enemy02Ded[0] = iLoadImage("images\\LevelOneEnemy\\Enemy02\\Dead01.png");
lv01Enemy02Ded[1] = iLoadImage("images\\LevelOneEnemy\\Enemy02\\Dead02.png");
lv01Enemy02Ded[2] = iLoadImage("images\\LevelOneEnemy\\Enemy02\\Dead03.png");


lv01Enemy03FWM[0] = iLoadImage("images\\LevelOneEnemy\\Enemy03\\001.png");
lv01Enemy03FWM[1] = iLoadImage("images\\LevelOneEnemy\\Enemy03\\002.png");
lv01Enemy03FWM[2] = iLoadImage("images\\LevelOneEnemy\\Enemy03\\003.png");


lv01Enemy03Atk[0] = iLoadImage("images\\LevelOneEnemy\\Enemy03\\Atk001.png"); 
lv01Enemy03Atk[1] = iLoadImage("images\\LevelOneEnemy\\Enemy03\\Atk002.png"); 
lv01Enemy03Atk[2] = iLoadImage("images\\LevelOneEnemy\\Enemy03\\Atk003.png"); 
lv01Enemy03Atk[3] = iLoadImage("images\\LevelOneEnemy\\Enemy03\\Atk004.png");


lv01Enemy03Ded[0] = iLoadImage("images\\LevelOneEnemy\\Enemy03\\Dead001.png");
lv01Enemy03Ded[1] = iLoadImage("images\\LevelOneEnemy\\Enemy03\\Dead002.png");



#endif new_Header